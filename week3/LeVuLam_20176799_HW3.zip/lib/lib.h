void get_ip(char *ip);
void get_domain(char *domain);